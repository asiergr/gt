from ._base_optimizer import _BaseOptimizer
class SGD(_BaseOptimizer):
    def __init__(self, model, learning_rate=1e-4, reg=1e-3, momentum=0.9):
        super().__init__(model, learning_rate, reg)
        self.momentum = momentum

        # initialize the velocity terms for each weight
        self.vw = []
        self.vb = []
        for i in range(len(model.modules)):
            self.vw.append([0])
            self.vb.append([0])

    def update(self, model):
        '''
        Update model weights based on gradients
        :param model: The model to be updated
        :return: None, but the model weights should be updated
        '''
        #self.apply_regularization(model)

        for idx, m in enumerate(model.modules):
            if hasattr(m, 'weight'):
                #############################################################################
                # TODO:                                                                     #
                #    1) Momentum updates for weights                                        #
                #############################################################################
                prev_v = self.vw[idx][-1]
                v = self.momentum * prev_v - self.learning_rate * m.dw
                self.vw[idx].append(v)
                m.weight += v
                #############################################################################
                #                              END OF YOUR CODE                             #
                #############################################################################
            if hasattr(m, 'bias'):
                #############################################################################
                # TODO:                                                                     #
                #    1) Momentum updates for bias                                           #
                #############################################################################
                prev_v = self.vb[idx][-1]
                v = self.momentum * prev_v - self.learning_rate * m.db
                self.vb[idx].append(v)
                m.bias += v
                
                #############################################################################
                #                              END OF YOUR CODE                             #
                #############################################################################
